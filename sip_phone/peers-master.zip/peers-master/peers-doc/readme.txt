use "mvn pre-site" command line to generate documentation.
